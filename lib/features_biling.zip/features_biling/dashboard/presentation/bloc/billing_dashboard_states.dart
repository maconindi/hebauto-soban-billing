
import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:hebauto/features_biling/dashboard/presentation/ui/billing_dashboard_main.dart';



part 'billing_dashboard_states.freezed.dart';

enum BillingDashboardStatus { initial, success, error, loading }

extension DashboardStatusX on BillingDashboardStatus {
  bool get isInitial => this == BillingDashboardStatus.initial;
  bool get isSuccess => this == BillingDashboardStatus.success;
  bool get isError => this == BillingDashboardStatus.error;
  bool get isLoading => this == BillingDashboardStatus.loading;
}

@freezed
abstract class BillingDashboardState with _$BillingDashboardState {
  factory BillingDashboardState({
    @Default('') String message,
    //@Default(0) int screen,
    // @Default(SizedBox()) Widget screen,
    @Default(Center(
      child: BillingDashboardMain(),
    )) Widget screen,
    @Default(BillingDashboardStatus.initial) BillingDashboardStatus status,
  }) = _BillingDashboardState;
}