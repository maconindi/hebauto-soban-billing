import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hebauto/core/services/hive/hive.dart';
import 'package:hebauto/core/util/ext/ext.dart';
import 'package:hebauto/injection.dart';

import '../../../../core/components/dx_image.dart';
import '../../../../core/components/dx_slidebar_item.dart';
import '../../../../core/routing/app_route.dart';
import '../../../../generated/assets.dart';

class DashboardSideBarBilling extends StatelessWidget {
  const DashboardSideBarBilling({
    super.key,
  });



  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 50),
      child: Column(
        children: [
          DxImage(
            url: AppAssets.imagesLogo,
            // width: context.width(),
            // height: context.height(),
          ),
          SingleChildScrollView(
            child: Column(
              children: [
                20.height,
                const Divider(),
                20.height,
                SlideBarItem(
                  text: 'Dashboard',
                  icon: Icons.computer,
                  onTap: () {


                  },
                ),
                SlideBarItem(
                  text: 'Sales Invoice',
                  icon: Icons.account_balance_rounded,
                  onTap: () {

                  },
                ),
                SlideBarItem(
                  text: 'Inventory',
                  icon: Icons.inventory_2_outlined,
                  onTap: () {


                  },
                ),
                SlideBarItem(
                  text: 'Credit Notes',
                  icon: Icons.notes,
                  onTap: () {

                  },
                ),
                SlideBarItem(
                  text: 'Receipts',
                  icon: Icons.receipt,
                  onTap: () {

                  },
                ),
                SlideBarItem(
                  text: 'Payments',
                  icon: Icons.payment_rounded,
                  onTap: () {

                  },
                ),


                SlideBarItem(
                  text: 'Purchase',
                  icon: Icons.pending_actions_rounded,
                  onTap: () {

                  },
                ),

                SlideBarItem(
                  text: 'Reports',
                  icon: Icons.file_present,
                  onTap: () {

                  },
                ),
                SlideBarItem(
                  text: 'Journal Entry',
                  icon: Icons.inventory_rounded,
                  onTap: () {

                  },
                ),

                30.height,
                SlideBarItem(
                  text: 'Settings',
                  icon: Icons.settings,
                  onTap: () {

                  },
                ),
                SlideBarItem(
                  text: 'Logout',
                  icon: Icons.logout,
                  onTap: () {
                    getIt<MainBoxMixin>().logoutBox().then((value) => {
                      context.go(Routes.customerLogin.path),
                      //context.read<CustomerDashboardBloc>().add(DashboardResetEvent())

                    });
                  },
                ),
              ],
            ),
          ).expand(),
        ],
      ),
    );
  }
}