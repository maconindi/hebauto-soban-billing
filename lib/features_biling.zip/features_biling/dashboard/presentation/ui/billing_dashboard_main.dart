import 'package:flutter/material.dart';
import 'package:hebauto/core/components/dx_text.dart';
import 'package:hebauto/core/util/ext/ext.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../../../core/components/fd_textfield.dart';
import '../../../../core/util/decorations.dart';

class BillingDashboardMain extends StatefulWidget {
  const BillingDashboardMain({super.key});

  @override
  State<BillingDashboardMain> createState() => _BillingDashboardMainState();
}


class SalesData {
  SalesData(DateTime dateTime, String s, double d, int i, this.y4, this.k, this.y, this.y3);

  final num k;
  final num y4;
  final num y;
  final num y3;
}



class ChartData {
  ChartData(this.x, this.y, this.y1, this.y2);
  final String x;
  final double? y;
  final double? y1;
  final double? y2;
}
class _BillingDashboardMainState extends State<BillingDashboardMain> {

  late List<ChartData> chartData;
  late TooltipBehavior _tooltip;

  final kBackgroundColor = Colors.grey.withOpacity(0.1);
  final kVerticalSpaces = 10.height;
  final kHorizontalSpaces = 5.width;



  @override
  void initState() {
   chartData = <ChartData>[
      ChartData('Jan', 128, 129, 101),
      ChartData('Feb', 123, 92, 93),
      ChartData('Mar', 107, 106, 90),
      ChartData('Apr', 87, 95, 71),
      ChartData('May', 87, 95, 71),
      ChartData('Jun', 87, 95, 71),
      ChartData('Jul', 87, 95, 71),
      ChartData('Aug', 87, 95, 71),
      ChartData('Sep', 87, 95, 71),
      ChartData('Oct', 87, 95, 71),
      ChartData('Nov', 87, 95, 71),
      ChartData('Dec', 87, 95, 71),
    ];
    _tooltip = TooltipBehavior(enable: true);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: SingleChildScrollView(
        child: Column(
          children: [
        
            20.height,
        
            /// Container Top 1
            ///
            Container(
              width: context.width(),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: boxDecorationWithRoundedCorners(backgroundColor: kBackgroundColor),
              child: Row(
                children: [
        
                  Padding(
                    padding: const EdgeInsets.only(top: 15),
                    child: FDTextField(
        
                      textFieldType: TextFieldType.NAME,
                      controller: TextEditingController(),
                      suffix: IconButton(
                        onPressed: () {
                        },
                        icon: const Icon(Icons.search_rounded),
                      ),
                      validator: (value) {
                        if (value?.isEmpty ?? false) {
                          return 'Email is required';
                        } else {
                          return null;
                        }
                      },
                      onChanged: (value){},
                      decoration: defaultInputDecoration(hint: 'Search vin, customer, invoice'),
                    )
                  ).expand(flex: 3),
        
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      const CircleAvatar(
                        child: Icon(Icons.add_alert),
                      ),
                      10.width,
                      const CircleAvatar(
                        child: Icon(Icons.person),
                      )
                    ],
                  ).expand(flex: 4)
        
                ],
              ),
            ),
        
            kVerticalSpaces,
            /// Container Top 2
            ///
            ///
            Row(
              children: [
                Container(
                  height: 150,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: boxDecorationWithRoundedCorners(backgroundColor: kBackgroundColor),
                ).expand(flex: 2),
                10.width,
        
                Container(
                  height: 150,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: boxDecorationWithRoundedCorners(backgroundColor: kBackgroundColor),
                ).expand(),
              ],
            ),
        
            kVerticalSpaces,
        
        
            /// Container Top 3
            ///
            ///
            Row(
              children: [
                Container(
                  height: 400,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: boxDecorationWithRoundedCorners(backgroundColor: kBackgroundColor),
                  child:
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const DxText(text: 'Sale and Expenses', size: 25, isBold: true,),
                      10.height,

                      SfCartesianChart(
                        tooltipBehavior: _tooltip,
                          primaryXAxis: CategoryAxis(name: 'Revenue'),
                          //primaryYAxis: CategoryAxis(labelPlacement: LabelPlacement.onTicks),
                          series: <CartesianSeries>[
                            ColumnSeries<ChartData, String>(
                                dataSource: chartData,
                                xValueMapper: (ChartData data, _) => data.x,
                                yValueMapper: (ChartData data, _) => data.y

                            ),
                            ColumnSeries<ChartData, String>(
                                dataSource: chartData,
                                xValueMapper: (ChartData data, _) => data.x,
                                yValueMapper: (ChartData data, _) => data.y1
                            ),
                            ColumnSeries<ChartData, String>(
                                dataSource: chartData,
                                xValueMapper: (ChartData data, _) => data.x,
                                yValueMapper: (ChartData data, _) => data.y2
                            )
                          ]
                      )
                      // SfCartesianChart(
                      //     primaryXAxis: CategoryAxis(),
                      //     primaryYAxis: NumericAxis(minimum: 0, maximum: 40, interval: 10),
                      //     tooltipBehavior: _tooltip,
                      //     series: <CartesianSeries<_ChartData, String>>[
                      //       ColumnSeries<_ChartData, String>(
                      //           dataSource: data,
                      //
                      //           xValueMapper: (_ChartData data, _) => data.x,
                      //           yValueMapper: (_ChartData data, _) => data.y,
                      //           name: 'Gold',
                      //           color: const Color.fromRGBO(8, 142, 255, 1))
                      //     ]
                      // ),
                    ],
                  )
                  ,
                ).expand(flex: 4),
                10.width,
        
                Container(
                  height: 400,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: boxDecorationWithRoundedCorners(backgroundColor: kBackgroundColor),
                ).expand(),
              ],
            ),
        
            kVerticalSpaces,
            /// Container Top 3
            ///
            ///


            Container(
              height: 400,
              width: context.width(),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: boxDecorationWithRoundedCorners(backgroundColor: kBackgroundColor),

            ),

        

        
        
        
          ],
        ),
      ),
    );
  }
}

