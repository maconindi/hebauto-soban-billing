import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hebauto/core/util/ext/ext.dart';

import '../bloc/billing_dashboard_bloc.dart';
import '../bloc/billing_dashboard_states.dart';
import '../widgets/billing_customer_sidebar.dart';

class BillingDashboardScreen extends StatefulWidget {
  const BillingDashboardScreen({super.key});

  @override
  State<BillingDashboardScreen> createState() => _BillingDashboardScreenState();
}

class _BillingDashboardScreenState extends State<BillingDashboardScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          context.isPhone() ? const SizedBox.shrink(): const DashboardSideBarBilling().expand(flex: 1),
          Column(
            children: [

              BlocBuilder<BillingDashboardBloc, BillingDashboardState>(
                builder: (context, state) {
                  return state.screen;
                },
              ).expand(),

            ],
          ).expand(flex: 5)
        ],
      ),
    );
}

}


